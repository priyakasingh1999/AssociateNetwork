import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { createGlobalStyle } from "styled-components";
import { Container, ImageList, ImageListItem, Typography } from "@mui/material";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import JoditEditor from "jodit-react";
import EmailIcon from "@mui/icons-material/Email";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import AddIcCallOutlinedIcon from "@mui/icons-material/AddIcCallOutlined";
import ForumOutlinedIcon from "@mui/icons-material/ForumOutlined";
import SettingsVoiceOutlinedIcon from "@mui/icons-material/SettingsVoiceOutlined";
import AlternateEmailOutlinedIcon from "@mui/icons-material/AlternateEmailOutlined";
import TwitterIcon from "@mui/icons-material/Twitter";
const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
}));

const Bgimg = createGlobalStyle`
.title:hover{
    border:2px solid black;
}
.title{
    border:2px solid transparent;
    padding:2px;
}
`;

const DiscussionReply = () => {
  return (
    <>
      <Box className="bgimg"></Box>
      <Bgimg />
      <Container maxWidth="lg">
        <Grid container spacing={0}>
          <Grid item xs={12} sx={{ backgroundColor: "#fff" }}>
            <Box
              sx={{
                backgroundColor: "#1688ca",
                color: "#fff",
                display: "flex",
                justifyContent: "left",
                gap: "10px",
                alignItems: "center",
                borderRadius: "unset",
                flexWrap: "wrap",
              }}
            >
              <Box className="title">
                <Typography sx={{ fontWeight: "bold", fontSize: "20px" }}>
                  Biomedical:
                </Typography>
              </Box>
              <Box>
                <Typography sx={{ fontSize: "17px" }}>
                  Added by Chris Hepple on 14 March 2023 at 14:35:49
                </Typography>
              </Box>
            </Box>
            <Container>
            <Grid container>
              <Grid item xs={12}>
                <Box
                  sx={{
                    textAlign: "center",
                    marginBottom: "10px",
                    marginTop: "5px",
                  }}
                >
                  <AddCircleOutlineIcon sx={{ color: "grey" }} />
                </Box>
              </Grid>
              
                <Grid item xs={3}>
                  <Box sx={{ padding: "20px", textAlign: "center" }}>
                    <Typography>Dashboard</Typography>

                    <ImageList cols={1}>
                      <ImageListItem>
                        <img src="./img/discussionreply.jpg" />
                      </ImageListItem>
                    </ImageList>
                    <Typography>Responses</Typography>
                    <Stack
                      direction="row"
                      sx={{ justifyContent: "space-around" }}
                      spacing={2}
                    >
                      <Box>
                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            fontSize: "12px",
                            backgroundColor: "green",
                          }}
                        >
                          3
                        </Avatar>
                        <Typography sx={{ fontSize: "14px" }}>Total</Typography>
                      </Box>
                      <Box>
                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            fontSize: "12px",
                            backgroundColor: "yellow",
                            color: "red",
                          }}
                        >
                          0
                        </Avatar>
                        <Typography sx={{ fontSize: "14px" }}>New</Typography>
                      </Box>
                    </Stack>

                    <Box>
                      <Stack
                        direction="row"
                        sx={{
                          justifyContent: "center",
                          paddingTop: "5px",
                          paddingBottom: "5px",
                          backgroundColor: "grey",
                          flexWrap: "wrap",
                        }}
                        spacing={2}
                      >
                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            backgroundColor: "transparent",
                            border: "2px solid #fff",
                          }}
                        >
                          <EmailIcon sx={{ fontSize: "15px" }} />
                        </Avatar>
                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            backgroundColor: "transparent",
                            border: "2px solid #fff",
                          }}
                        >
                          <EmailOutlinedIcon sx={{ fontSize: "15px" }} />
                        </Avatar>

                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            backgroundColor: "transparent",
                            border: "2px solid #fff",
                          }}
                        >
                          <ForumOutlinedIcon sx={{ fontSize: "15px" }} />
                        </Avatar>
                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            backgroundColor: "transparent",
                            border: "2px solid #fff",
                          }}
                        >
                          <SettingsVoiceOutlinedIcon
                            sx={{ fontSize: "15px" }}
                          />
                        </Avatar>
                        <Avatar
                          sx={{
                            width: "25px",
                            height: "25px",
                            backgroundColor: "transparent",
                            border: "2px solid #fff",
                          }}
                        >
                          <AlternateEmailOutlinedIcon
                            sx={{ fontSize: "15px" }}
                          />
                        </Avatar>
                      </Stack>
                      <Box>
                        <Typography
                          sx={{
                            textAlign: "center",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          Actions
                        </Typography>
                      </Box>
                      <Box>
                        <Typography
                          sx={{
                            fontWeight: "bold",
                            textAlign: "center",
                            marginTop: "10px",
                            fontSize: "15px",
                          }}
                        >
                          Direct Files
                        </Typography>
                        <Box sx={{ display: "flex", border: "2px solid grey" }}>
                          <Box>12</Box>
                          <Box>12</Box>
                        </Box>
                      </Box>
                    </Box>
                  </Box>
                </Grid>

                <Grid item xs={7}>
                  <Box
                    sx={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <Box sx={{ display: "flex" }}>
                      <AddCircleOutlineIcon
                        sx={{ color: "grey", width: "22px", height: "22px" }}
                      />{" "}
                      <AddCircleOutlineIcon
                        sx={{ color: "grey", width: "22px", height: "22px" }}
                      />{" "}
                      <AddCircleOutlineIcon
                        sx={{ color: "grey", width: "22px", height: "22px" }}
                      />
                    </Box>
                    <Box>
                      <Typography sx={{ fontSize: "15px" }}>
                        Station Sessions
                      </Typography>
                    </Box>

                    <Box sx={{ display: "flex", gap: "5px" }}>
                      {" "}
                      <ChevronLeftIcon
                        sx={{
                          backgroundColor: "#5a585d",
                          width: "21px",
                          height: "21px",
                          borderRadius: "50%",
                          color: "#fff",
                        }}
                      />{" "}
                      <ChevronRightIcon
                        sx={{
                          backgroundColor: "#5a585d",
                          borderRadius: "50%",
                          width: "21px",
                          height: "21px",
                          color: "#fff",
                        }}
                      />
                    </Box>
                  </Box>
                  <Box sx={{ border: "1px solid lightgray", padding: "10px" }}>
                    <Box>
                      <Stack direction="row" spacing={2}>
                        <Avatar alt="Remy Sharp" src="./img/john.jpg" />
                        <Box>
                          <Typography
                            sx={{ fontSize: "15px", fontWeight: "bold" }}
                          >
                            Chris Hepple
                          </Typography>
                          <Typography
                            sx={{ fontSize: "12px", color: "#655f5f" }}
                          >
                            03/14 2:35 PM
                          </Typography>
                        </Box>
                      </Stack>
                    </Box>
                    <Typography sx={{ fontSize: "14px", marginBottom: "10px" }}>
                      Our new Bi-plane Imaging suite is completed. It is state
                      of the art. We received donations for most of this cost.
                      This will greatly improved imaging services and enhance
                      patient care. Thanks
                    </Typography>
                    <ImageList cols={1} sx={{ borderRadius: "15px" }}>
                      <ImageListItem>
                        <img src="./img/station_867.jpg" />
                      </ImageListItem>
                    </ImageList>
                  </Box>
                  <Box>
                    <Box>
                      <Stack direction="row" spacing={2}>
                        <Avatar alt="Remy Sharp" src="./img/john.jpg" />
                        <Box>
                          <Typography
                            sx={{ fontSize: "15px", fontWeight: "bold" }}
                          >
                            John S Smith
                          </Typography>
                          <Typography
                            sx={{ fontSize: "12px", color: "#655f5f" }}
                          >
                            03:08 pm
                          </Typography>
                        </Box>
                      </Stack>
                    </Box>
                    <Typography sx={{ fontSize: "14px", marginBottom: "10px" }}>
                      This is great investment for our patients to provide them
                      the latest technology there is. Thank you for your hard
                      work everyone.
                    </Typography>
                  </Box>
                  <Box>
                    <Box>
                      <Stack direction="row" spacing={2}>
                        <Avatar alt="Remy Sharp" src="./img/john.jpg" />
                        <Box>
                          <Typography
                            sx={{ fontSize: "15px", fontWeight: "bold" }}
                          >
                            John S Smith
                          </Typography>
                          <Typography
                            sx={{ fontSize: "12px", color: "#655f5f" }}
                          >
                            03:08 pm
                          </Typography>
                        </Box>
                      </Stack>
                    </Box>
                    <Typography sx={{ fontSize: "14px", marginBottom: "10px" }}>
                      nice
                    </Typography>
                  </Box>
                  <Box>
                    <Box>
                      <Stack direction="row" spacing={2}>
                        <Avatar alt="Remy Sharp" src="./img/john.jpg" />
                        <Box>
                          <Typography
                            sx={{ fontSize: "15px", fontWeight: "bold" }}
                          >
                            John S Smith
                          </Typography>
                          <Typography
                            sx={{ fontSize: "12px", color: "#655f5f" }}
                          >
                            03:08 pm
                          </Typography>
                        </Box>
                      </Stack>
                    </Box>
                    <Typography sx={{ fontSize: "14px", marginBottom: "10px" }}>
                      web
                    </Typography>
                  </Box>
                  <Box>
                    <JoditEditor />
                  </Box>
                </Grid>
            </Grid>
            </Container>
          </Grid>
        </Grid>
      </Container>
    </>
  );
};

export default DiscussionReply;
